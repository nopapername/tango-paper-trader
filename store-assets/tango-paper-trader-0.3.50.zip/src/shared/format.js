(function initFormat(global) {
  const Tango = global.Tango = global.Tango || {};
  const numberFormatters = new Map();

  function numberFormatter(language, digits, compactMode = false) {
    const locale = language === 'zh-CN' ? 'zh-CN' : 'en-US';
    // Two locales, two styles and21 precisions bound this cache to84 entries.
    // Other inputs still go through Intl's original coercion and validation.
    const cacheable = typeof digits === 'number' && Number.isInteger(digits) && digits >= 0 && digits <= 20;
    const key = cacheable ? `${locale}:${compactMode}:${digits}` : null;
    if (cacheable && numberFormatters.has(key)) return numberFormatters.get(key);
    const formatter = new Intl.NumberFormat(locale, compactMode
      ? { notation: 'compact', maximumFractionDigits: digits }
      : { maximumFractionDigits: digits });
    if (cacheable) numberFormatters.set(key, formatter);
    return formatter;
  }

  function compact(value, language, maximumFractionDigits = 2) {
    if (!Number.isFinite(Number(value))) return '--';
    return numberFormatter(language, maximumFractionDigits, true).format(Number(value));
  }

  function number(value, language, digits = 4) {
    if (!Number.isFinite(Number(value))) return '--';
    return numberFormatter(language, digits).format(Number(value));
  }

  function native(value, symbol, language, signed = false) {
    if (!Number.isFinite(Number(value))) return '--';
    const numeric = Number(value || 0);
    const sign = signed && numeric > 0 ? '+' : numeric < 0 ? '-' : '';
    return `${sign}${number(Math.abs(numeric), language, 4)} ${String(symbol || '').trim()}`.trim();
  }

  function sol(value, language, signed = false) {
    return native(value, 'SOL', language, signed);
  }

  function percent(value, language, signed = false) {
    if (!Number.isFinite(Number(value))) return '--';
    const numeric = Number(value);
    const sign = signed && numeric > 0 ? '+' : '';
    return `${sign}${number(numeric, language, 2)}%`;
  }

  function usd(value, language, compactMode = false) {
    if (!Number.isFinite(Number(value))) return '--';
    const numeric = Number(value);
    if (compactMode) return `$${compact(numeric, language, 2)}`;
    const digits = Math.abs(numeric) < 0.01 ? 10 : 4;
    return `$${number(numeric, language, digits)}`;
  }

  function dateTimeFormatter(language) {
    // One formatter per rendered batch: reuse rows without retaining a stale
    // system time zone after a user changes their OS settings.
    const formatter = new Intl.DateTimeFormat(language, {
      year: 'numeric', month: 'numeric', day: 'numeric',
      hour: 'numeric', minute: 'numeric', second: 'numeric'
    });
    return value => {
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? date.toLocaleString(language) : formatter.format(date);
    };
  }

  function duration(ms, language) {
    const seconds = Math.max(0, Math.floor(Number(ms || 0) / 1000));
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ${seconds % 60}s`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ${minutes % 60}m`;
    const days = Math.floor(hours / 24);
    return language === 'zh-CN' ? `${days}天 ${hours % 24}小时` : `${days}d ${hours % 24}h`;
  }

  Tango.Format = { compact, number, native, sol, percent, usd, duration, dateTimeFormatter };
})(globalThis);
